package com.zespol11.programowanienzespolowe.userRegistration.email;

public interface EmailSender {
    void send(String to, String email);
}