package com.zespol11.programowanienzespolowe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramowanienzespoloweApplicationTests {

	@Test
	void contextLoads() {
	}

}
